﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace company
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Company company = new Company();
            Console.WriteLine("enter the customers");
            Customer c1 = new Customer();
            Order order = new Order();
            OrderItem orderItem = new OrderItem();
            Item i1=new Item();
            i1.Name = "soap";
            i1.Rate = 10;
            orderItem.item = i1;
            orderItem.qty = 10;
            order.ordereditems.Add(orderItem);
            c1.orders.Add(order);

            Customer c2 = new Customer();
            Order order2 = new Order();
            OrderItem orderItem2 = new OrderItem();
            Item i2 = new Item();
            i2.Name = "cap";
            i2.Rate = 10;
            orderItem2.item = i2;
            orderItem2.qty = 5;
            order2.ordereditems.Add(orderItem2);
            c2.orders.Add(order2);

            Customer c3 = new Customer();
            Order order3 = new Order();
            OrderItem orderItem3 = new OrderItem();
            Item i3 = new Item();
            i3.Name = "cap";
            i3.Rate = 10;
            orderItem3.item = i2;
            orderItem3.qty = 5;
            order3.ordereditems.Add(orderItem2);
            c3.orders.Add(order2);

            RegCustomer c4 = new RegCustomer();
            Order order4 = new Order();
            OrderItem orderItem4 = new OrderItem();
            Item i4 = new Item();
            i4.Name = "bottle";
            i4.Rate = 10;
            orderItem4.item = i4;
            orderItem4.qty = 5;
            order4.ordereditems.Add(orderItem4);
            c4.orders.Add(order4);
            c4.getSpecialDiscount = 10;

            company.customers = new List<Customer> { c1, c2, c3, c4 };
            Console.WriteLine($"{company.TotalWorthOfOrdersPlaced()}");
        }
    }
    class Company
    {
        List<Item> Items {  get; set; }=new List<Item>();
       public List<Customer> customers { get; set; } = new List<Customer>();
       public double TotalWorthOfOrdersPlaced()
        {
            double sum = 0;
           foreach(Customer customer in customers)
            {
                foreach(Order order in customer.orders)
                {
                    foreach(OrderItem o in order.ordereditems)
                    {
                        sum += o.item.Rate * o.qty;
                    }

                }
            }
           double total = 0,cost=0;
           foreach(Customer customer in customers)
            {
                if(customer as RegCustomer != null)  {
                    RegCustomer c = (RegCustomer)customer;
                cost = 0;
                foreach(Order order in c.orders)
                {
                    foreach(OrderItem o1 in order.ordereditems)
                    {
                        cost+= o1.item.Rate * o1.qty;
                        
                    }
                }
                total += total-( c.getSpecialDiscount * cost)/100;
            }
            }
            return sum+total;
        }
    }
    class Item
    {
      public string Name { get; set; }
        public double Rate { get; set; }
    }
    class Customer
    {
        public List <Order> orders { get; set; }=new List<Order>();
    }
    class RegCustomer:Customer
    {

        public double getSpecialDiscount {  get; set; }
    }
    class Order
    {
        public List<OrderItem> ordereditems { get; set; }=new List<OrderItem>();
    }
    class OrderItem
    { 
        public Item item { get; set; }
        public int qty { get; set; }
    }
}
